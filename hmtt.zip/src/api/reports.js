// 反馈面板的数据 弄个单独文件是方便管理
export const firstActions = [
  { name: '不感兴趣' },
  { name: '反馈垃圾内容' }
]

export const secondActions = [
  {
    value: 0,
    name: '其它问题'
  },
  {
    value: 1,
    name: '标题夸张'
  },
  {
    value: 2,
    name: '低俗色情'
  },
  {
    value: 3,
    name: '错别字多'
  },
  {
    value: 4,
    name: '旧闻重复'
  },
  {
    value: 6,
    name: '内容不实'
  },
  {
    value: 8,
    name: '侵权'
  },
  {
    value: 5,
    name: '广告软文'
  },
  {
    value: 7,
    name: '涉嫌违法犯罪'
  }
]
