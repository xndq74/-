import { Toast } from 'vant'

export default ({ type, message }) => {
  Toast({
    type,
    message
  })
}
